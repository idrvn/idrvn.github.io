# IDRVN — placeholder site

Pre-launch homepage for IDRVN Private Limited (under incorporation).

## Files
- `index.html` — the whole site, single self-contained file. Now includes canonical/robots meta tags and an Organization JSON-LD block in `<head>`, and the contact button/email is `contact@idrvn.com`.
- `favicon.svg` — the compact इ mark, used as the browser tab icon
- `.nojekyll` — tells GitHub Pages to serve files as-is, skip Jekyll processing
- `CNAME` — set to `www.idrvn.com`; delete this file if you're not pointing the domain here yet
- `robots.txt` — allows all crawlers, points to the sitemap
- `sitemap.xml` — single-URL sitemap for the homepage; update `<lastmod>` when you make real content changes

## Deploy to GitHub Pages

1. Create a new GitHub repo (public, or private on a paid plan) and push these files to the root of the `main` branch. No `src` folder, no build step, just these four files at the top level.
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **Deploy from a branch**.
4. Branch: `main`, folder: `/ (root)`. Save.
5. GitHub gives you a URL like `https://<username>.github.io/<repo-name>/` within a minute or two. That confirms the deploy works before touching DNS.

## Pointing www.idrvn.com at it (once you're ready)

1. Keep the `CNAME` file in the repo (already set to `www.idrvn.com`).
2. At your domain registrar, add a `CNAME` record: host `www`, value `<username>.github.io`.
3. Back in **Settings → Pages**, the custom domain field should pick up `www.idrvn.com` automatically once the DNS record resolves (can take a few hours). Check "Enforce HTTPS" once the certificate is issued.
4. If you want the bare `idrvn.com` (no `www`) to also work, add `A` records at your registrar pointing the apex domain to GitHub's IPs (185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153), and set up a redirect from apex to `www`.

## Editing later
Everything, HTML, CSS, and JS, lives in `index.html`. No dependencies to install, no build step. Open it in any text editor, save, commit, push, done.

## Getting the site to show up correctly on Google

1. Go to [Google Search Console](https://search.google.com/search-console) and add a **Domain** property for `idrvn.com` (this covers `www` and non-`www`, http and https, in one property).
2. Verify by DNS: Search Console gives you a TXT record value. Add it at GoDaddy as a `TXT` record, host `@`, with that value. Verification usually clears within minutes to a few hours.
3. Once verified, go to **Sitemaps** in the left sidebar and submit `https://www.idrvn.com/sitemap.xml`.
4. Use **URL Inspection** (top search bar in Search Console), enter `https://www.idrvn.com/`, and click **Request Indexing**. This asks Google to recrawl the page now rather than waiting for its next scheduled crawl — this is what replaces a stale snippet from a previous domain owner.
5. Recrawling and snippet updates aren't instant — allow anywhere from a few days to a couple of weeks for the old "interior design services" description to fully clear from search results, even after Search Console shows the page as indexed.
